package assignment3;
import java.lang.Math;


public class Calculator {
    private double  x;
    private double  y;
    private String choice;

    public Calculator(double x, double y, String choice ) {
        this.x = x;
        this.y = y;
    }

    public String getChoice() {
        return choice;
    }

    public void setChoice(String choice) {
        this.choice = choice;
    }

    
    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double addition(double x, double y){
        double sum = x+y;
        return sum;
    }

    public double multiplication(double x, double y){
        double mult=x*y;
        return mult;
    }
    
public void division() 
    { 
        if (y == 0) { 
            System.out.print("Infinite"); 
            return; 
        } 
        if (x == 0) { 
            System.out.print("0"); 
            return; 
        } else{
            System.out.print(x / y); 
            return; 
        } 
    
}
public double subtraction(double x, double y){
    double sub=x-y;
    return sub;
}

  public void  power() 
    { 
        double pow; 
        if( y == 0) 
            System.out.println("1");
        else 
            System.out.println(Math.pow(x, y));
    } 

  public void Sin(){
      // converting values to radians
        double xRad = Math.toRadians(x); 
  
        System.out.println(Math.sin(xRad)); 
 
       double yRad = Math.toRadians(y); 
  
        System.out.println(Math.sin(yRad)); 
  
        
  }
  
  public void Cos(){
      // converting values to radians
        double xRad = Math.toRadians(x); 
  
        System.out.println(Math.cos(xRad)); 
 
       double yRad = Math.toRadians(y); 
  
        System.out.println(Math.cos(yRad)); 
       
  }
  
  public void Log(){
      if(x<0 && y<0){
          System.out.print("Invalid values. Enter values greater than 0");
      }
      else if(x==0 && y==0){
          System.out.print("Infinite. Enter values greater than zero:");
          
          }else{
           System.out.println(Math.log(x)); 
            System.out.println(Math.log(y)); 
      }
      
  }
  
  
}