/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class CalculatorTest {
    public static void main(String args[]){
        Scanner input = new Scanner(System.in);
        
        Calculator calcExample= new Calculator(0,0, " ");
        
        System.out.println("Enter two numbers :");
        
        double x = input.nextInt();
        calcExample.setX(x);
        
        double y = input.nextInt();
        calcExample.setY(y);
        
        System.out.println("Choose form the menu, the operations:  ");
        System.out.println(" A- Addition ");
        System.out.println(" M- Multiplication ");
        System.out.println(" D- Division");
        System.out.println(" S- Subtraction");
        System.out.println(" P- Power ");
        System.out.println(" T- Sin ");
        System.out.println(" R- Cos ");
        System.out.println(" L- Log ");
        
        input.nextLine();
        String choice = input.nextLine();
        calcExample.setChoice(choice);
        
        
        
        switch(choice){
            
        case "A":
        case "a":
        System.out.println("Addition:");
       System.out.println (calcExample.addition(x, y));
        break;
        
        
        case "M":
        case "m":
            System.out.println("Multiplication");
           System.out.println( calcExample.multiplication(x, y));
        break;
        
        case "D":
        case "d":
            System.out.println("Division");
            calcExample.division();
        break;
        
        case "S":
        case "s":
            System.out.println("Subtraction");
           System.out.println( calcExample.subtraction(x, y));
        break;
        
        case "P":
        case "p":
            System.out.println("Power ");
            calcExample.power();
        break;
        
        
        case "T":
        case "t":
            System.out.println("Sin");
            calcExample.Sin();
        break;
        
        case "R":
        case "r":
            System.out.println("Cos");
            calcExample.Cos();
        break;
        
        case "L":
        case "l":
            System.out.println("Log");
            calcExample.Log();
        break;
        default:
            System.out.println("Choose from letters in the menu:");
        break;
        
    }
        
        
    }}
