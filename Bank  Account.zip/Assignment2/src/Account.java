
public class Account {
    private String name;
    private String surname;
    private String address;
    private int phoneNumber;
    private double balance;
    private String choice;
   
    
  
    
    

    public Account(String name, String surname, String address, int phoneNumber, double balance, String choice  ){
        this.name = name;
        this.surname = surname;
        this.address = address;
        this.phoneNumber = phoneNumber;
        
        if(balance>0)
        this.balance = balance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        if(balance>0)
        this.balance = balance;
    }

    public String getChoice() {
        return choice;
    }

    public void setChoice(String choice) {
        this.choice = choice;
    }

 
    
    public double credit(double amountC){
        balance= balance+amountC;
        
        return balance;
        
    }
    
       public double debit(double amountD){
        balance= balance-amountD;
        
        return balance;
        
    }
       
       public double IncreaseBalance (double perc){
           perc=perc/100;
           balance= balance + balance*perc;
           return balance;
       }
}
