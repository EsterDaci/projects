import java.util.Scanner;

public class AccountTest {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        
        Account customerAcc=new Account(" " , " ", " ", 0,0, " " );
        
        System.out.println("The customer account data are :");
        
        System.out.println("Please enter the customer name:");
        String name = input.nextLine();
        customerAcc.setName(name);
        
        
        System.out.println("Please enter the customer surname:");
        String surname = input.nextLine();
        customerAcc.setSurname(surname);
        
        
        System.out.println("Please enter the customer address :");
        String address = input.nextLine();
        customerAcc.setAddress(address);
        
        
        System.out.println("Please enter the customer phone number :");
        int phoneNumber = input.nextInt();
        customerAcc.setPhoneNumber(phoneNumber);
        
        
        
        System.out.println("Please enter the customer first balance  :");
        double balance = input.nextDouble();
        customerAcc.setBalance(balance);
        
        
        
        System.out.println("Enter the transaction you want to make :");
        System.out.println("C or c for credit &  W or w for withdraw :");
        
        
        input.nextLine();
        String choice = input.nextLine();
        customerAcc.setChoice(choice);
        
        
        
        System.out.println("A new account is opened :");
        System.out.println("The customer data for this new account /n ");
        
        System.out.println("Name of the customer :" + customerAcc.getName());
        System.out.println("Surname of the customer :"+ customerAcc.getSurname());
        System.out.println("The address of the customer :"+customerAcc.getAddress());
        System.out.println("The phone number of this customer :"+ customerAcc.getPhoneNumber());
        System.out.println("The first balance this customer deposit is : " + customerAcc.getBalance());
        
        System.out.println("The transaction  you choose is :"+ customerAcc.getChoice());
        
        switch(choice){
            
        case "C":
        case "c":
        System.out.println("Please enter the customer credit amount   :");
        double amountC = input.nextDouble();
        customerAcc.credit(amountC);
        break;
        
        case "W":
        case "w":
             System.out.println("Please enter the customer cwithdraw amount   :");
        double amountD = input.nextDouble();
        customerAcc.debit(amountD);
        break;
        
        default:
            System.out.println("Invalid input:");
            break;
        } 
        System.out.println("The last operation performed is :"+ customerAcc.getChoice() );
        
        System.out.println("Enter the percentage that your balance has increase :");
        double perc = input.nextDouble();
        customerAcc.IncreaseBalance(perc);
        
        System.out.println("Yor new balance is :"+ customerAcc.IncreaseBalance(perc));
    }
    
}
